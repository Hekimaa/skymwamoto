jQuery(function() {
	fr = new FilmRoll({
		container: '#film_roll',
	});
  return true;
});
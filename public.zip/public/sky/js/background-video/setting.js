(function($) {
  'use strict';
    // Setting
    $('.my-background-video').bgVideo({
        fadeIn: 500,
        fadeOnEnd: false,
        fadeOnPause: true,
        pausePlayYPos: 'center',
        pausePlayXPos: 'center',
        pausePlayXOffset: '0px',
        pausePlayYOffset: '0px'
    });
})(jQuery);
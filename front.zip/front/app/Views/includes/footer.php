<!-- Start footer -->
<footer>
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="widget">
						
						<p>"Nothing but breathing the air of Africa and actually walikng through it can communicate the indescribable
					sensations"</p>
						<div class="social-network">
							<a href="https://www.instagram.com/sky_mwamoto/"><i class="icon icon-facebook"></i></a>
							<a href="https://www.instagram.com/sky_mwamoto/"><i class="icon icon-twitter"></i></a>
							<a href="https://www.instagram.com/sky_mwamoto/"><i class="icon icon-linkedin"></i></a>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="widget">
						<h4>Useful link</h4>
						<ul class="link-list">
							<li><a href="<?= base_url('/contacts')?>">Contact Us</a></li>
							<li><a href="<?= base_url()?>/volunteerings">Volunteering</a></li>
							<li><a href="<?= base_url('/destinations/all_destinations')?>">Destinations</a></li>
							<li><a href="<?= base_url('/tours-and-safari')?>">Tours and Safari</a></li>

						
						</ul>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="widget">
						<h4>Volunteering</h4>
						<ul class="recent-post-list">
						
							<li>
								<h6><a href="<?= base_url('volunteerings')?>">Midwives and Nursing project</a></h6>
							</li>
							<li>
								<h6><a href="<?= base_url('volunteerings')?>">Teaching project</a></h6>
							</li>
							<li>
								<h6><a href="<?= base_url('volunteerings')?>">Medical project</a></h6>
							</li>
						
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="subfooter">
			<p>2022 &copy; Copyright<b style="color:#c0392b;">   Skymwamoto Tours and Safari.</b> All rights Reserved.</p>
		</div>
	</footer>
	
	<!-- Start to top -->  
    <a href="#" class="toTop">
        <i class="fa fa-chevron-up"></i>
    </a>  
    <!-- End to top -->
